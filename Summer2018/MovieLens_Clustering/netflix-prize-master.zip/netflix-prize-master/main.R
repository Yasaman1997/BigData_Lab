library(dplyr)
library(ggplot2)
library(ggrepel)
library(readr)
library(tidyr)

RMSE <- function(realRatings, predictedRatings) {
  # Root-mean-square error
  squaredErrors <- (realRatings - predictedRatings)^2
  mean <- mean(squaredErrors)
  return(sqrt(mean))
}

PATH <- getwd()
ratings <- read_csv(gzfile(paste(PATH, "/data/movielens-train.csv", sep="")))
movies <- read_csv(gzfile(paste(PATH, "/data/movie.csv", sep="")))

# PROBLEM 1A
ratings %>%
  summarize(
    nUsers=n_distinct(userId),
    nMovies=n_distinct(movieId),
    minRating=min(rating),
    maxRating=max(rating))

# PROBLEM 1B
userData <- group_by(ratings, userId)
summarize(
    summarize(userMovies=n(), userData),
    median=median(userMovies),
    max=max(userMovies))

rm(userData)

# PROBLEM 1C
set.seed(755)
test <- sample_frac(ratings, 1/10)
train <- setdiff(ratings, test)
rm(ratings)

# PROBLEM 1D
result1D <- RMSE(c(4,3,3,4), c(4.5,3.5,1,4))
print(result1D)

# PROBLEM 2A
avgRating <- mean(train$rating)
result2A <- RMSE(test$rating, rep(avgRating, nrow(test)))
print(result2A)

# PROBLEM 2B
movieData <- group_by(train, movieId) %>%
  summarize(bias=mean(rating - avgRating),
            qty=n())

pdf(paste(PATH, "/observations/movie-deviation-from-mean.pdf", sep=""))
ggplot(movieData, aes(bias)) + geom_histogram(bins=21)
dev.off()

prediction <- left_join(test, movieData, by="movieId") %>%
  replace_na(list(bias=0))
result2B <- RMSE(test$rating, avgRating+prediction$bias)

print(result2B)
rm(prediction)

# PROBLEM 2C
moviesBias <- left_join(movies, movieData, by="movieId")

arrange(moviesBias, bias) %>% 
  select(title, qty, bias) %>% 
  print(n=10)
arrange(moviesBias, desc(bias)) %>% 
  select(title, qty, bias) %>% 
  print(n=10)
rm(moviesBias); rm(movieData)

# PROBLEM 2D
lambda <- 5
movieRegMeans <- train %>%
  group_by(movieId) %>% 
  summarize(bias=sum(rating - avgRating)/(n()+lambda), 
            qty=n())

movieRegMeans <- left_join(movies, movieRegMeans, by="movieId")

arrange(movieRegMeans, bias) %>% 
  select(title, qty, bias) %>% 
  print(n=10)
arrange(movieRegMeans, desc(bias)) %>% 
  select(title, qty, bias) %>% 
  print(n=10)

prediction <- left_join(test, movieRegMeans, by="movieId") %>%
  replace_na(list(bias=0))
result2D <- RMSE(test$rating, avgRating+prediction$bias)

print(result2D)

#PROBLEM 2E
userMeans <- group_by(train, userId) %>% 
  summarize(userBias=mean(rating))

pdf(paste(PATH, "/observations/user-avg-rating.pdf", sep=""))
ggplot(userMeans, aes(userBias)) + geom_histogram(bins=21)
dev.off()
rm(userMeans)

alpha <- 10
userRegMeans <- train %>%
  left_join(movieRegMeans) %>%
  mutate(resids = rating-avgRating-bias) %>% 
  group_by(userId) %>%
  summarize(userBias = sum(resids)/(n()+alpha))

prediction <- test %>% 
  left_join(movieRegMeans, by='movieId') %>% 
  left_join(userRegMeans, by='userId') %>% 
  replace_na(list(bias=0, userBias=0))

predicted_ratings <- avgRating + prediction$bias + prediction$userBias
result2E <- RMSE(test$rating, predicted_ratings)
print(result2E); rm(prediction)

# PROBLEM 3
train_small <- train %>%
  filter(movieId %in% unique(test$movieId) & userId %in% unique(test$userId)) %>%
  group_by(movieId) %>%
  filter(n()>=5000) %>%
  ungroup %>%
  group_by(userId) %>%
  filter(n()>=250) %>%
  ungroup

rm(train)

# PROBLEM 3A
train_small <- train_small %>%
  left_join(movieRegMeans) %>%
  left_join(userRegMeans) %>%
  mutate(resids = rating-avgRating-bias-userBias)

head(train_small)

# PROBLEM 3B
movies$genres <- NULL
movies$title <- gsub('.{7}$', '', movies$title)

Y <- train_small %>% 
  select(userId, movieId, resids) %>%
  spread(userId, resids) %>% 
  left_join(movies)
rm(train_small); rm(movies)

movie_ids <- Y$movieId
movie_titles <- Y$title

Y <- select(Y, -movieId, -title) %>%
  as.matrix()
Y <- ifelse(is.na(Y[,]), 0, Y[,])

pca <- prcomp(Y, center=FALSE, scale=FALSE)
df <- data_frame(PC2=pca$x[,1], 
                  PC1=pca$x[,2], 
                  name=movie_titles)
keep <- c(
  arrange(df, PC1) %>% slice(1:10) %>% .$name,
  arrange(df, desc(PC2)) %>% slice(1:10) %>% .$name,
  arrange(df, PC1) %>% slice(1:10) %>% .$name,
  arrange(df, desc(PC2)) %>% slice(1:10) %>% .$name)

pdf(paste(PATH, "/observations/movies-primary-components.pdf", sep=""))
df %>% ggplot(aes(PC1, PC2)) + geom_point() + 
              geom_text_repel(aes(PC1, PC2, label=name), 
              data=filter(df, name %in% keep))
dev.off(); rm(df)

# PROBLEM 3C
k <- 20
pred <- pca$x[,1:k] %*% t(pca$rotation[,1:k])
colnames(pred) <- colnames(Y)
rm(Y); 

interaction <- 
  data.frame(movieId=movie_ids, pred, check.names=FALSE) %>% 
  tbl_df %>%
  gather(userId, userBiasForMovie, -movieId) %>% 
  mutate(userId=as.numeric(userId))
rm(pred)

prediction <- test %>% 
  left_join(movieRegMeans, by='movieId') %>% 
  left_join(userRegMeans, by='userId') %>% 
  left_join(interaction, by=c('movieId','userId')) %>%
  replace_na(list(bias=0, userBias=0, userBiasForMovie=0))
rm(interaction); rm(userRegMeans); rm(movieRegMeans)

predicted_ratings <- avgRating + prediction$bias + 
                     prediction$userBias + prediction$userBiasForMovie
result3C <- RMSE(test$rating, predicted_ratings)
print(result3C); rm(test); rm(prediction)

# PROBLEM 3D
names = c("Naive", "Movie Bias", "Bayesian Regularization", "User Bias", "LDA")
results = c(result2A, result2B, result2D, result2E, result3C)
print(data.frame(model=names, rmse=results))