![](https://image.ibb.co/ht1RnG/4e21fcfa_a867_11e6_9027_87691a234431.png)

# Netflix Prize

The [Netflix Prize](https://www.netflixprize.com/) was an annual competition promoted by Netflix and pursued until 2009, soughting to substantially improve the accuracy of predictions about how much someone is going to enjoy a movie based on their movie preferences. In 2009, the team BellKor's Pragmatic Chaos had their algorithm awarded with the Grand Prize, achieving the winning RMSE of <code>0.8567</code> on the test subset. 

This project's objective was to use statistical approaches in R language to create and optimize a recommendation algorithm, using the same dataset as the one provided for the contestants in the competition. This was achieved by:

* Training different models by considering a diverse range methods (such as *LDA* and *Bayesian Regularization*);
* Creating visualizations to explore bias factors and patterns (as described by Netflix);
* And finally, comparing the improvement through the same RMSE method used in the competition.

Furthermore, it was possible to achieve a RMSE of <code>0.8729</code>, which is pretty close to those of the winning team and represents an improvement of 8.39% in comparison to the original Netflix's Cinematch algorithm.

**Special acknowledgment:** Rafael Irizarry & Heather Mattie, professors of Biostatistics in Harvard's School of Public Health, for developing this project for the [BST 260: Introduction to Data Science course](http://datasciencelabs.github.io/).
