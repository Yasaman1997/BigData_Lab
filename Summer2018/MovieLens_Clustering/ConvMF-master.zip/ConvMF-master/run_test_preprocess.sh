python ./run.py \
-d ./test/ml-10m/0.2/ \
-a ./test/ml-10m/ \
-c True \
-r ./data/movielens/ml-10m_ratings.dat \
-i ./data/movielens/Plot.idmap \
-m 1
