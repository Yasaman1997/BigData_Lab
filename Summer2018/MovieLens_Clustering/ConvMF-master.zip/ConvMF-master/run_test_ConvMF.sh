python ./run.py \
-d ../data/preprocessed/movielens_10m/cf/0.2_1/ \
-a ../data/preprocessed/movielens_10m/ \
-o ./test/movielens_10m/result/1_100_200 \
-e 200 \
-p ../data/preprocessed/glove/glove.6B.200d.txt \
-u 10 \
-v 100 \
-g True
