# TCC
Recommender System using movielens 100k dataset (https://grouplens.org/datasets/movielens/)
![alt text](http://lukascivil.com.br/githubimages/TCC/Figure_1.png)
![alt text](http://lukascivil.com.br/githubimages/TCC/Figure_2.png)
![alt text](http://lukascivil.com.br/githubimages/TCC/Figure_3.png)
